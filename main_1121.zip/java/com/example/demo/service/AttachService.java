package com.example.demo.service;

import com.example.demo.entity.Attach;

import java.util.List;

public interface AttachService {
    List<Attach> attachList(Attach attach);
}
